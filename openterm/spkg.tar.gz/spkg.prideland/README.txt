README:
mainrepo.txt stores main repository info
(by default it is sn3ksoftware/sandboxrepo)
repolist.txt stores list of all added repositories
(also by default only sn3ksoftware/sandboxrepo is included.)